const express = require('express');
const router = express.Router();
const { listConfigs, upsertConfig, removeConfig, setActive } = require('./services/vpnService');

// Helpers
function getUserId(req) {
  return (req.query.userId || req.headers['x-user-id'] || 'default').toString();
}

// GET /api/vpn/configs?userId=...
router.get('/configs', (req, res) => {
  const userId = getUserId(req);
  const data = listConfigs(userId);
  res.json({ userId, ...data });
});

// POST /api/vpn/configs
router.post('/configs', (req, res) => {
  const userId = getUserId(req);
  const cfg = req.body || {};
  if (!cfg.server) return res.status(400).json({ error: 'server is required' });
  const saved = upsertConfig(userId, cfg);
  res.json({ success: true, config: saved });
});

// PUT /api/vpn/configs/:id
router.put('/configs/:id', (req, res) => {
  const userId = getUserId(req);
  const cfg = { ...(req.body || {}), id: req.params.id };
  const saved = upsertConfig(userId, cfg);
  res.json({ success: true, config: saved });
});

// DELETE /api/vpn/configs/:id
router.delete('/configs/:id', (req, res) => {
  const userId = getUserId(req);
  const ok = removeConfig(userId, req.params.id);
  if (!ok) return res.status(404).json({ error: 'Config not found' });
  res.json({ success: true });
});

// POST /api/vpn/active { id }
router.post('/active', (req, res) => {
  const userId = getUserId(req);
  const { id } = req.body || {};
  if (!id) return res.status(400).json({ error: 'id is required' });
  const data = setActive(userId, id);
  if (!data) return res.status(404).json({ error: 'Config not found' });
  res.json({ success: true, userId, activeId: data.activeId });
});

module.exports = router;
