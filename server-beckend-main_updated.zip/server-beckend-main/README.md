# server-beckend

API backend (Express) para Business Manage.

## Ejecutar

```bash
npm install
npm start
```

Servidor: `http://localhost:5000`  
API base: `http://localhost:5000/api`

## Nuevas funcionalidades

### 1) Almacenar configuraciones de VPN dinámicas
Rutas:

- `GET  /api/vpn/configs?userId=demo`
- `POST /api/vpn/configs?userId=demo`
- `PUT  /api/vpn/configs/:id?userId=demo`
- `DELETE /api/vpn/configs/:id?userId=demo`
- `POST /api/vpn/active?userId=demo` body: `{ "id": "VPN-..." }`

> Nota: se guardan en `data/vpn_configs.json`. En producción, no guardes contraseñas en texto plano; usa un KMS/Secret Manager.

### 2) Gestionar historial de SOS en la nube (Cloud Evidence)
Rutas:

- `POST /api/sos/alert` body: `{ "type": "medical", "location": {...}, "contacts": [...] }`
- `GET  /api/sos/history?limit=50&offset=0&status=OPEN`
- `GET  /api/sos/:incidentId`
- `POST /api/sos/:incidentId/note` body: `{ "note": "texto", "actor": "operador" }`
- `POST /api/sos/:incidentId/close`

Se guarda en `data/cloud_evidence.json`.

### 3) Sincronizar "Royal Academy" y puntuaciones de lealtad
Rutas:

- `GET  /api/royal-academy/status?userId=demo`
- `POST /api/royal-academy/complete?userId=demo` body: `{ "courseId": "c1", "score": 85 }`
- `POST /api/royal-academy/sync?userId=demo`

Regla por defecto: `puntos_lealtad += (delta_score) * 10` (solo suma, no resta).

Lealtad:

- `GET  /api/loyalty/status?userId=demo`
- `GET  /api/loyalty/history?userId=demo`
- `POST /api/loyalty/points?userId=demo` body: `{ "action": "purchase", "points": 200 }`

## Persistencia
Se usa un storage sencillo basado en JSON bajo `./data/` (modo dev / single-instance).
