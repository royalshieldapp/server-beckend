const express = require('express');
const router = express.Router();
const { createIncident, listIncidents, getIncident, addNote, closeIncident } = require('./services/cloudEvidenceService');

// POST /api/sos/alert
router.post('/alert', async (req, res) => {
  const { location, type, contacts } = req.body || {};

  // minimal validation
  if (!type) return res.status(400).json({ error: 'type is required (e.g., medical, security, fire)' });

  const incidentId = `INC-${Date.now()}`;

  const incident = createIncident({
    incidentId,
    type: String(type),
    location: location || null,
    contacts: Array.isArray(contacts) ? contacts : [],
    source: {
      ip: req.ip,
      userAgent: req.get('user-agent') || null,
    },
  });

  // TODO: Integrate Twilio here to send SMS/Call
  // const client = require('twilio')(accountSid, authToken);
  // await client.messages.create({ ... });

  res.json({
    success: true,
    message: 'SOS Alert received and stored in Cloud Evidence',
    incidentId: incident.incidentId,
    createdAt: incident.createdAt,
  });
});

// GET /api/sos/history?limit=50&offset=0&status=OPEN
router.get('/history', (req, res) => {
  const limit = Math.min(200, Math.max(1, Number(req.query.limit) || 50));
  const offset = Math.max(0, Number(req.query.offset) || 0);
  const status = req.query.status ? String(req.query.status) : undefined;
  const type = req.query.type ? String(req.query.type) : undefined;

  const data = listIncidents({ limit, offset, status, type });
  res.json({ ...data, limit, offset });
});

// GET /api/sos/:incidentId
router.get('/:incidentId', (req, res) => {
  const incident = getIncident(req.params.incidentId);
  if (!incident) return res.status(404).json({ error: 'Incident not found' });
  res.json(incident);
});

// POST /api/sos/:incidentId/note { note, actor }
router.post('/:incidentId/note', (req, res) => {
  const { note, actor } = req.body || {};
  if (!note) return res.status(400).json({ error: 'note is required' });
  const incident = addNote(req.params.incidentId, String(note), actor ? String(actor) : 'system');
  if (!incident) return res.status(404).json({ error: 'Incident not found' });
  res.json({ success: true, incident });
});

// POST /api/sos/:incidentId/close
router.post('/:incidentId/close', (req, res) => {
  const incident = closeIncident(req.params.incidentId);
  if (!incident) return res.status(404).json({ error: 'Incident not found' });
  res.json({ success: true, incident });
});

module.exports = router;
