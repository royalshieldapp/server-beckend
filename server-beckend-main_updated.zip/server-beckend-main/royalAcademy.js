const express = require('express');
const router = express.Router();
const { getAcademy, completeCourse, sync } = require('./services/royalAcademyService');

function getUserId(req) {
  return (req.query.userId || req.headers['x-user-id'] || 'default').toString();
}

// GET /api/royal-academy/status
router.get('/status', (req, res) => {
  const userId = getUserId(req);
  const academy = getAcademy(userId);
  res.json({ userId, ...academy });
});

// POST /api/royal-academy/complete
router.post('/complete', (req, res) => {
  const userId = getUserId(req);
  const { courseId, score } = req.body || {};
  if (!courseId) return res.status(400).json({ error: 'courseId is required' });
  const result = completeCourse(userId, courseId.toString(), score);
  res.json({ success: true, ...result });
});

// POST /api/royal-academy/sync
router.post('/sync', (req, res) => {
  const userId = getUserId(req);
  const result = sync(userId);
  res.json({ success: true, ...result });
});

module.exports = router;
