const express = require('express');
const router = express.Router();

const phoneRoutes = require('./phone');
const sosRoutes = require('./sos');
const threatRoutes = require('./threats');
const courseRoutes = require('./courses');
const systemRoutes = require('./system');
const loyaltyRoutes = require('./loyalty');
const scanRoutes = require('./scan');

// New: dynamic VPN configs + Royal Academy sync
const vpnRoutes = require('./vpn');
const royalAcademyRoutes = require('./royalAcademy');

router.use('/phone', phoneRoutes);
router.use('/sos', sosRoutes);
router.use('/threats', threatRoutes);
router.use('/courses', courseRoutes);
router.use('/system', systemRoutes);
router.use('/loyalty', loyaltyRoutes);
router.use('/scan', scanRoutes);

router.use('/vpn', vpnRoutes);
router.use('/royal-academy', royalAcademyRoutes);

module.exports = router;
