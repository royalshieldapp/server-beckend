const path = require('path');
const { readJson, writeJsonAtomic } = require('../utils/storage');
const { addPoints, getUser } = require('./loyaltyService');

const ACADEMY_FILE = path.join(__dirname, '..', 'data', 'royal_academy.json');

/**
 * Royal Academy state:
 * { users: { [userId]: { completed: { [courseId]: { score, completedAt } }, totalScore, updatedAt } } }
 */
function load() {
  return readJson(ACADEMY_FILE, { users: {} });
}
function save(state) {
  writeJsonAtomic(ACADEMY_FILE, state);
}

function getAcademy(userId = 'default') {
  const state = load();
  if (!state.users[userId]) {
    state.users[userId] = { completed: {}, totalScore: 0, updatedAt: new Date().toISOString() };
    save(state);
  }
  return state.users[userId];
}

/**
 * Completes a course and awards loyalty points.
 * Default award: floor(score) points (0-100) * 10
 */
function completeCourse(userId = 'default', courseId, score = 0) {
  const state = load();
  if (!state.users[userId]) state.users[userId] = { completed: {}, totalScore: 0, updatedAt: new Date().toISOString() };

  const s = Math.max(0, Math.min(100, Number(score) || 0));
  const now = new Date().toISOString();

  const user = state.users[userId];
  const already = user.completed[courseId];

  user.completed[courseId] = { score: s, completedAt: now };
  user.totalScore = Object.values(user.completed).reduce((acc, v) => acc + (Number(v.score) || 0), 0);
  user.updatedAt = now;

  save(state);

  // Loyalty sync: award points only for first completion, or delta for improved score
  const prevScore = already ? (Number(already.score) || 0) : 0;
  const deltaScore = s - prevScore;
  const awarded = Math.floor(deltaScore) * 10;
  let loyalty = getUser(userId);
  if (awarded > 0) {
    loyalty = addPoints(userId, awarded, `royal_academy:${courseId}`);
  }

  return { academy: user, loyalty, awardedPoints: Math.max(0, awarded) };
}

/**
 * Full re-sync based on academy score.
 * Desired loyalty contribution = totalScore * 10.
 * Adds the difference as points (never subtract).
 */
function sync(userId = 'default') {
  const academy = getAcademy(userId);
  const desired = Math.floor(academy.totalScore) * 10;
  const loyalty = getUser(userId);
  const diff = desired - loyalty.points;
  let updated = loyalty;
  if (diff > 0) updated = addPoints(userId, diff, 'royal_academy:sync');
  return { academy, loyalty: updated, desiredContribution: desired, added: Math.max(0, diff) };
}

module.exports = { getAcademy, completeCourse, sync };
