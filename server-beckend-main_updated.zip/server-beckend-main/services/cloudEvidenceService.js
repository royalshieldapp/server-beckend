const path = require('path');
const crypto = require('crypto');
const { readJson, writeJsonAtomic } = require('../utils/storage');

const EVIDENCE_FILE = path.join(__dirname, '..', 'data', 'cloud_evidence.json');

function load() {
  return readJson(EVIDENCE_FILE, { incidents: [] });
}

function save(state) {
  writeJsonAtomic(EVIDENCE_FILE, state);
}

function createIncident(payload) {
  const state = load();
  const incidentId = payload.incidentId || `INC-${Date.now()}`;
  const incident = {
    incidentId,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    status: 'OPEN',
    type: payload.type || 'SOS',
    location: payload.location || null,
    contacts: payload.contacts || [],
    source: payload.source || {},
    notes: [],
    evidence: [],
    // Simple integrity hash for the incident record (not a substitute for real evidence chain)
    integrity: { algo: 'sha256', hash: null },
  };

  // compute integrity
  const hash = crypto.createHash('sha256').update(JSON.stringify({ ...incident, integrity: { algo: 'sha256', hash: null } })).digest('hex');
  incident.integrity.hash = hash;

  state.incidents.unshift(incident);
  // keep last 1000
  state.incidents = state.incidents.slice(0, 1000);
  save(state);
  return incident;
}

function listIncidents({ limit = 50, offset = 0, status, type } = {}) {
  const state = load();
  let items = state.incidents;
  if (status) items = items.filter(i => i.status === status);
  if (type) items = items.filter(i => i.type === type);
  return {
    total: items.length,
    items: items.slice(offset, offset + limit),
  };
}

function getIncident(incidentId) {
  const state = load();
  return state.incidents.find(i => i.incidentId === incidentId) || null;
}

function addNote(incidentId, note, actor = 'system') {
  const state = load();
  const idx = state.incidents.findIndex(i => i.incidentId === incidentId);
  if (idx === -1) return null;

  state.incidents[idx].notes.unshift({
    id: `NOTE-${Date.now()}`,
    actor,
    note,
    at: new Date().toISOString(),
  });
  state.incidents[idx].updatedAt = new Date().toISOString();
  save(state);
  return state.incidents[idx];
}

function closeIncident(incidentId) {
  const state = load();
  const idx = state.incidents.findIndex(i => i.incidentId === incidentId);
  if (idx === -1) return null;
  state.incidents[idx].status = 'CLOSED';
  state.incidents[idx].updatedAt = new Date().toISOString();
  save(state);
  return state.incidents[idx];
}

module.exports = { createIncident, listIncidents, getIncident, addNote, closeIncident };
