const path = require('path');
const { readJson, writeJsonAtomic } = require('../utils/storage');

const VPN_FILE = path.join(__dirname, '..', 'data', 'vpn_configs.json');

function load() {
  return readJson(VPN_FILE, { users: {} });
}

function save(state) {
  writeJsonAtomic(VPN_FILE, state);
}

function listConfigs(userId = 'default') {
  const state = load();
  const u = state.users[userId] || { configs: [], activeId: null, updatedAt: new Date().toISOString() };
  return u;
}

function upsertConfig(userId = 'default', cfg) {
  const state = load();
  if (!state.users[userId]) state.users[userId] = { configs: [], activeId: null, updatedAt: new Date().toISOString() };

  const user = state.users[userId];
  const now = new Date().toISOString();

  const id = cfg.id || `VPN-${Date.now()}`;
  const clean = {
    id,
    name: String(cfg.name || 'VPN Config'),
    protocol: String(cfg.protocol || 'wireguard'),
    server: String(cfg.server || ''),
    port: cfg.port != null ? Number(cfg.port) : null,
    username: cfg.username != null ? String(cfg.username) : null,
    // DO NOT store plaintext passwords in production. Use a secret manager / KMS.
    password: cfg.password != null ? String(cfg.password) : null,
    extra: typeof cfg.extra === 'object' && cfg.extra ? cfg.extra : {},
    createdAt: cfg.createdAt || now,
    updatedAt: now,
  };

  const idx = user.configs.findIndex(c => c.id === id);
  if (idx === -1) user.configs.unshift(clean);
  else user.configs[idx] = { ...user.configs[idx], ...clean };

  user.updatedAt = now;
  // keep last 200
  user.configs = user.configs.slice(0, 200);

  save(state);
  return clean;
}

function removeConfig(userId = 'default', id) {
  const state = load();
  const user = state.users[userId];
  if (!user) return false;
  const before = user.configs.length;
  user.configs = user.configs.filter(c => c.id !== id);
  if (user.activeId === id) user.activeId = null;
  user.updatedAt = new Date().toISOString();
  save(state);
  return user.configs.length !== before;
}

function setActive(userId = 'default', id) {
  const state = load();
  if (!state.users[userId]) state.users[userId] = { configs: [], activeId: null, updatedAt: new Date().toISOString() };
  const user = state.users[userId];
  const exists = user.configs.some(c => c.id === id);
  if (!exists) return null;
  user.activeId = id;
  user.updatedAt = new Date().toISOString();
  save(state);
  return user;
}

module.exports = { listConfigs, upsertConfig, removeConfig, setActive };
