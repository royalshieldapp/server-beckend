const path = require('path');
const { readJson, writeJsonAtomic } = require('../utils/storage');

const LOYALTY_FILE = path.join(__dirname, '..', 'data', 'loyalty.json');

function computeTier(points) {
  if (points >= 5000) return 'Platinum';
  if (points >= 1000) return 'Gold';
  if (points >= 200) return 'Silver';
  return 'Bronze';
}

function load() {
  return readJson(LOYALTY_FILE, { users: {} });
}

function save(state) {
  writeJsonAtomic(LOYALTY_FILE, state);
}

function getUser(userId = 'default') {
  const state = load();
  if (!state.users[userId]) {
    state.users[userId] = {
      points: 0,
      tier: 'Bronze',
      history: [],
      updatedAt: new Date().toISOString(),
    };
    save(state);
  }
  return state.users[userId];
}

function addPoints(userId = 'default', points, action = 'manual') {
  if (!Number.isFinite(points)) throw new Error('Invalid points');
  const state = load();
  if (!state.users[userId]) state.users[userId] = { points: 0, tier: 'Bronze', history: [], updatedAt: new Date().toISOString() };

  state.users[userId].points += points;
  state.users[userId].tier = computeTier(state.users[userId].points);
  state.users[userId].updatedAt = new Date().toISOString();
  state.users[userId].history.unshift({
    id: `LP-${Date.now()}`,
    action,
    points,
    at: new Date().toISOString(),
  });
  // keep last 200
  state.users[userId].history = state.users[userId].history.slice(0, 200);

  save(state);
  return state.users[userId];
}

module.exports = { computeTier, getUser, addPoints };
