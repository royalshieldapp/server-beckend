const express = require('express');
const router = express.Router();
const { getUser, addPoints, computeTier } = require('./services/loyaltyService');

function getUserId(req) {
  return (req.query.userId || req.headers['x-user-id'] || 'default').toString();
}

// GET /api/loyalty/status?userId=...
router.get('/status', (req, res) => {
  const userId = getUserId(req);
  const user = getUser(userId);
  const nextTier = user.tier === 'Platinum' ? null : (user.tier === 'Gold' ? 'Platinum' : user.tier === 'Silver' ? 'Gold' : 'Silver');
  const thresholds = { Bronze: 200, Silver: 1000, Gold: 5000, Platinum: null };
  const pointsToNextTier = thresholds[user.tier] == null ? 0 : Math.max(0, thresholds[user.tier] - user.points);

  res.json({
    userId,
    points: user.points,
    tier: user.tier,
    nextTier,
    pointsToNextTier,
    updatedAt: user.updatedAt,
  });
});

// GET /api/loyalty/history?userId=...
router.get('/history', (req, res) => {
  const userId = getUserId(req);
  const user = getUser(userId);
  res.json({ userId, history: user.history || [] });
});

// POST /api/loyalty/points
router.post('/points', (req, res) => {
  const userId = getUserId(req);
  const { action, points } = req.body || {};
  const n = Number(points);

  if (!Number.isFinite(n)) return res.status(400).json({ error: 'points must be a number' });
  if (n === 0) return res.status(400).json({ error: 'points cannot be 0' });

  const updated = addPoints(userId, n, action || 'manual');

  res.json({
    success: true,
    message: `Added ${n} points for ${action || 'manual'}`,
    newTotal: updated.points,
    currentTier: updated.tier,
  });
});

module.exports = router;
