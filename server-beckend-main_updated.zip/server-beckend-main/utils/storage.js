const fs = require('fs');
const path = require('path');

/**
 * Very small JSON file storage helper.
 * - Stores data under /data/*.json
 * - Uses atomic write (write temp then rename)
 * NOTE: This is fine for dev/single-instance. For production, use a real DB.
 */
function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) fs.mkdirSync(dirPath, { recursive: true });
}

function readJson(filePath, fallback) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    const raw = fs.readFileSync(filePath, 'utf-8');
    if (!raw.trim()) return fallback;
    return JSON.parse(raw);
  } catch (err) {
    console.warn(`[storage] readJson failed for ${filePath}:`, err.message);
    return fallback;
  }
}

function writeJsonAtomic(filePath, data) {
  ensureDir(path.dirname(filePath));
  const tmp = `${filePath}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tmp, filePath);
}

module.exports = { ensureDir, readJson, writeJsonAtomic };
